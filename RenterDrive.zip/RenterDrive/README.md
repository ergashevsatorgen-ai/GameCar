# RenterCode Drive
Android (WebView) + HTML o'yin. O'yin kodi: app/src/main/assets/index.html
Server: server/rc_server.php (hostingga yuklang, ADMIN_KEY ni o'zgartiring).
APK: Android Studio -> Build APK(s)  yoki  GitHub Actions.
Admin: o'yinga "adminrenter" ismi bilan kiring.
